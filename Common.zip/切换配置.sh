MODDIR="${0%/*}"

echo "请选择模式："
echo "  1) 切换为 App + Game 模式"
echo "  2) 切换为 纯 App 模式"
echo "  q) 退出"
echo ""
printf "输入选择 (1/2/q): "

read choice

success=0

case "$choice" in
  1)
    echo "正在切换为 App + Game 模式..."

    [ -f "$MODDIR/Game/module.prop" ] && cp -f "$MODDIR/Game/module.prop" "$MODDIR/module.prop" 2>/dev/null && success=1
    [ -f "$MODDIR/Game/action.sh"   ] && cp -f "$MODDIR/Game/action.sh"   "$MODDIR/action.sh"   2>/dev/null && success=1
    [ -f "$MODDIR/Game/Nijika.png"     ] && cp -f "$MODDIR/Game/Nijika.png"     "$MODDIR/Nijika.png"     2>/dev/null

    if [ -f "$MODDIR/App/applist.conf" ] && [ -f "$MODDIR/Game/applist.conf" ]; then
      cat "$MODDIR/App/applist.conf" "$MODDIR/Game/applist.conf" > "$MODDIR/applist.conf.tmp" 2>/dev/null
      mv -f "$MODDIR/applist.conf.tmp" "$MODDIR/applist.conf" 2>/dev/null
    elif [ -f "$MODDIR/Game/applist.conf" ]; then
      cp -f "$MODDIR/Game/applist.conf" "$MODDIR/applist.conf" 2>/dev/null
    fi

    rm -f "$MODDIR/Ikuyo.png" 2>/dev/null

    if [ "$success" = "1" ]; then
      echo "已切换为 App+Game 模式"
    fi
    ;;

  2)
    echo "正在切换为纯 App 模式..."

    [ -f "$MODDIR/App/module.prop"  ] && cp -f "$MODDIR/App/module.prop"  "$MODDIR/module.prop"  2>/dev/null && success=1
    [ -f "$MODDIR/App/action.sh"    ] && cp -f "$MODDIR/App/action.sh"    "$MODDIR/action.sh"    2>/dev/null && success=1
    [ -f "$MODDIR/App/Ikuyo.png"   ] && cp -f "$MODDIR/App/Ikuyo.png"   "$MODDIR/Ikuyo.png"   2>/dev/null

    [ -f "$MODDIR/App/applist.conf" ] && cp -f "$MODDIR/App/applist.conf" "$MODDIR/applist.conf" 2>/dev/null

    rm -f "$MODDIR/Nijika.png" 2>/dev/null

    if [ "$success" = "1" ]; then
      echo "已切换为 App 模式"
    fi
    ;;

  q|Q|exit|quit)
    echo "已退出"
    exit 0
    ;;

  *)
    echo "无效输入，仅接受 1 / 2 / q"
    exit 1
    ;;
esac

# 无论成功与否都显示这条
if [ "$choice" = "1" ] || [ "$choice" = "2" ]; then
  echo "建议重新执行 Action 更新线程"
fi

echo "操作完成。"
read -r dummy