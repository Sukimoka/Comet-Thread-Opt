SKIPUNZIP=0
check_magisk_version() {
	ui_print "- Magisk version: $MAGISK_VER_CODE"
	ui_print "- Module version: $(grep_prop version "${TMPDIR}/module.prop")"
	ui_print "- Module versionCode: $(grep_prop versionCode "${TMPDIR}/module.prop")"
	ui_print "********************************************"
	ui_print "- $(grep_prop description "${TMPDIR}/module.prop")"
	if [ "$MAGISK_VER_CODE" -lt 20400 ]; then
		ui_print "********************************************"
		ui_print "! 请安装 Magisk v20.4+ (20400+)"
		abort    "********************************************"
	fi
}
check_required_files() {
	REQUIRED_FILE_LIST="/sys/devices/system/cpu/present /proc/loadavg"
	for REQUIRED_FILE in $REQUIRED_FILE_LIST; do
		if [ ! -e $REQUIRED_FILE ]; then
			ui_print "********************************************"
			ui_print "! $REQUIRED_FILE 文件不存在"
			ui_print "! 请联系模块作者"
			abort    "********************************************"
		fi
	done
}
extract_bin() {
	ui_print "********************************************"
	if [ "$ARCH" == "arm" ]; then
		cp $MODPATH/bin/armeabi-v7a/AppOpt $MODPATH
	elif [ "$ARCH" == "arm64" ]; then
		cp $MODPATH/bin/arm64-v8a/AppOpt $MODPATH
	elif [ "$ARCH" == "x86" ]; then
		cp $MODPATH/bin/x86/AppOpt $MODPATH
	elif [ "$ARCH" == "x64" ]; then
		cp $MODPATH/bin/x86_64/AppOpt -v $MODPATH
	else
		abort "! Unsupported platform: $ARCH"
	fi
	ui_print "- Device platform: $ARCH"
	rm -rf $MODPATH/bin
	[ -f $MODPATH/AppOpt ] && chmod a+x $MODPATH/AppOpt
	if ! $MODPATH/AppOpt -v; then
		abort "! 主程序验证失败，请检查模块zip文件是否损坏"
	fi
}
remove_sys_perf_config() {
	for SYSPERFCONFIG in $(ls /system/vendor/bin/msm_irqbalance); do
		[[ ! -d $MODPATH${SYSPERFCONFIG%/*} ]] && mkdir -p $MODPATH${SYSPERFCONFIG%/*}
		ui_print "- Remove :$SYSPERFCONFIG"
		touch $MODPATH$SYSPERFCONFIG
	done
	if [ -n "$(pm path com.xiaomi.joyose)" ] && [ -n "$(getprop ro.miui.ui.version.code)" ]; then
		pm disable --user 0 com.xiaomi.joyose/.smartop.SmartOpService
		echo 'pm enable com.xiaomi.joyose/.smartop.SmartOpService' >> $MODPATH/uninstall.sh
	fi
}
module_instructions() {
	ui_print "********************************************"
	ui_print "线程规则配置文件路径为："
	ui_print "/data/adb/modules/AppOpt/applist.conf"
	ui_print "------------------------------------------"
	ui_print "修改与添加规则无需重启，即时生效"
	ui_print "********************************************"
	cores=$(for cpus in /sys/devices/system/cpu/cpufreq/*/related_cpus; do 
		[ -f "$cpus" ] && cat "$cpus" | wc -w
	done | paste -sd+)
	ui_print "当前$(getprop ro.soc.model)设备为$(nproc)核CPU，规格是：$cores"
	ui_print "可用CPU范围：$(cat /sys/devices/system/cpu/present)"
	ui_print "------------------------------------------"
	ui_print "applist.conf 规则写法示例："
	ui_print "------------------------------------------"
	max_freq=0
	best_policy=""
	for policy in /sys/devices/system/cpu/cpufreq/policy*; do
		if [ -f "${policy}/related_cpus" ] && [ -f "${policy}/cpuinfo_max_freq" ]; then
			policy_num="${policy##*policy}"
			cpus=$(cat "${policy}/related_cpus" 2>/dev/null)
			first_cpu="${cpus%% *}"
			last_cpu="${cpus##* }"
			if [ "$first_cpu" = "$last_cpu" ]; then
				core_range="$first_cpu"
			else
				core_range="${first_cpu}-${last_cpu}"
			fi
			if [ "$policy" == '/sys/devices/system/cpu/cpufreq/policy0' ]; then
				ui_print "将 '微信' 消息推送子进程绑定能效小核 簇${policy_num}："
				ui_print "com.tencent.mm:push=${core_range}"
			else
				ui_print "将 '微信' 主进程绑定到 簇${policy_num}："
				ui_print "com.tencent.mm=${core_range}"
			fi
			ui_print "------------------------------------------"
			current_max=$(cat "${policy}/cpuinfo_max_freq" 2>/dev/null)
			if [ -n "$current_max" ] && [ "$current_max" -gt "$max_freq" ]; then
				max_freq="$current_max"
				best_policy="${policy_num}:${core_range}"
			fi
		fi
	done
	if [ -n "$best_policy" ]; then
		policy_num="${best_policy%:*}"
		core_range="${best_policy#*:}"
		ui_print "CPU：${core_range} 为当前设备的性能大核（簇${policy_num}）"
		ui_print "频率最高：$((max_freq/1000)) MHz"
		ui_print "------------------------------------------"
		ui_print "将 '王者荣耀' 的 UnityMain 线程绑定到性能大核："
		ui_print "com.tencent.tmgp.sgame{UnityMain}=${core_range}"
	fi
	ui_print "------------------------------------------"
	ui_print "更多规则使用说明请参考："
	ui_print "http://AppOpt.suto.top"
	ui_print "********************************************"
}
check_magisk_version
check_required_files
extract_bin
remove_sys_perf_config
module_instructions
if [ -f /data/adb/modules/AppOpt/applist.conf ]; then
	mv $MODPATH/applist.conf $MODPATH/applist.conf.bak
	cp -r /data/adb/modules/AppOpt/applist.conf ${MODPATH}
fi
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm_recursive "$MODPATH/*.sh $MODPATH/AppOpt" 0 2000 0755 0755 u:object_r:magisk_file:s0
